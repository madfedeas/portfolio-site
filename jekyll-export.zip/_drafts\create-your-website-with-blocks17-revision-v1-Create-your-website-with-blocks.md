---
id: 25
title: Create your website with blocks
date: 2021-01-25T01:11:48+00:00
author: mad.fed.eas
layout: revision
guid: http://localhost/wordpress/2021/01/25/17-revision-v1/
permalink: /2021/01/25/17-revision-v1/
---
<h2 class="alignwide has-text-align-wide has-gigantic-font-size" style="line-height:1.1">
  Create your website with blocks
</h2>

<div style="height:100px" aria-hidden="true" class="wp-block-spacer">
</div>

<div class="wp-block-columns alignwide are-vertically-aligned-center is-style-twentytwentyone-columns-overlap">
  <div class="wp-block-column is-vertically-aligned-center">
    <figure class="wp-block-image alignfull size-large"><img src="http://localhost/wordpress/wp-content/themes/twentytwentyone/assets/images/roses-tremieres-hollyhocks-1884.jpg" alt="&#8220;Roses Tremieres&#8221; by Berthe Morisot" /></figure> 
    
    <div style="height:100px" aria-hidden="true" class="wp-block-spacer">
    </div><figure class="wp-block-image alignfull size-large is-style-twentytwentyone-image-frame">
    
    <img src="http://localhost/wordpress/wp-content/themes/twentytwentyone/assets/images/in-the-bois-de-boulogne.jpg" alt="&#8220;In the Bois de Boulogne&#8221; by Berthe Morisot" /></figure>
  </div>
  
  <div class="wp-block-column is-vertically-aligned-center">
    <div style="height:100px" aria-hidden="true" class="wp-block-spacer">
    </div><figure class="wp-block-image size-large alignfull size-full is-style-twentytwentyone-border">
    
    <img src="http://localhost/wordpress/wp-content/themes/twentytwentyone/assets/images/young-woman-in-mauve.jpg" alt="&#8220;Young Woman in Mauve&#8221; by Berthe Morisot" /></figure>
  </div>
</div>

<div style="height:50px" aria-hidden="true" class="wp-block-spacer">
</div>

<div class="wp-block-columns alignwide are-vertically-aligned-top">
  <div class="wp-block-column is-vertically-aligned-top">
    <h3>
      Add block patterns
    </h3>
    
    <p>
      Block patterns are pre-designed groups of blocks. To add one, select the Add Block button [+] in the toolbar at the top of the editor. Switch to the Patterns tab underneath the search bar, and choose a pattern.
    </p>
  </div>
  
  <div class="wp-block-column is-vertically-aligned-top">
    <h3>
      Frame your images
    </h3>
    
    <p>
      Twenty Twenty-One includes stylish borders for your content. With an Image block selected, open the "Styles" panel within the Editor sidebar. Select the "Frame" block style to activate it.
    </p>
  </div>
  
  <div class="wp-block-column is-vertically-aligned-top">
    <h3>
      Overlap columns
    </h3>
    
    <p>
      Twenty Twenty-One also includes an overlap style for column blocks. With a Columns block selected, open the "Styles" panel within the Editor sidebar. Choose the "Overlap" block style to try it out.
    </p>
  </div>
</div>

<div style="height:100px" aria-hidden="true" class="wp-block-spacer">
</div>

<div class="wp-block-cover alignwide has-green-background-color has-background-dim is-style-twentytwentyone-border">
  <div class="wp-block-cover__inner-container">
    <div style="height:20px" aria-hidden="true" class="wp-block-spacer">
    </div>
    
    <p class="has-huge-font-size">
      Need help?
    </p>
    
    <div style="height:75px" aria-hidden="true" class="wp-block-spacer">
    </div>
    
    <div class="wp-block-columns">
      <div class="wp-block-column">
        <p>
          <a href="https://wordpress.org/support/article/twenty-twenty-one/">Read the Theme Documentation</a>
        </p>
      </div>
      
      <div class="wp-block-column">
        <p>
          <a href="https://wordpress.org/support/theme/twentytwentyone/">Check out the Support Forums</a>
        </p>
      </div>
    </div>
    
    <div style="height:20px" aria-hidden="true" class="wp-block-spacer">
    </div>
  </div>
</div>