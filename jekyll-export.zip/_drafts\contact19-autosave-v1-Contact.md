---
id: 98
title: Contact
date: 2021-02-04T07:14:01+00:00
author: mad.fed.eas
layout: revision
guid: http://localhost/wordpress/2021/02/04/19-autosave-v1/
permalink: /2021/02/04/19-autosave-v1/
---
Me: **Madison Federin-Easley**

Email: **mad.fed.eas@gmail.com**

Resume: <a href="http://resume.pdf" data-type="URL" data-id="resume.pdf"><strong>Download here</strong></a>

LinkedIn: [<span style="color:#1995ca" class="has-inline-color"><strong>https://www.linkedin.com/in/madison-federin-easley-089572b9/</strong></span>](https://www.linkedin.com/in/madison-federin-easley-089572b9/)