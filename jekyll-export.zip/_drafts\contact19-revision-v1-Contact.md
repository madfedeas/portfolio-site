---
id: 99
title: Contact
date: 2021-02-04T07:14:20+00:00
author: mad.fed.eas
layout: revision
guid: http://localhost/wordpress/2021/02/04/19-revision-v1/
permalink: /2021/02/04/19-revision-v1/
---
Me: **<span class="has-inline-color has-yellow-color">Madison Federin-Easley</span>**

Email: **<span class="has-inline-color has-yellow-color">mad.fed.eas@gmail.com</span>**

Resume: <a href="http://resume.pdf" data-type="URL" data-id="resume.pdf"><strong>Download here</strong></a>

LinkedIn: [<span style="color:#1995ca" class="has-inline-color"><strong>https://www.linkedin.com/in/madison-federin-easley-089572b9/</strong></span>](https://www.linkedin.com/in/madison-federin-easley-089572b9/)