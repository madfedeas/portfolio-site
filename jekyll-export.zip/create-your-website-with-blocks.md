---
id: 17
title: My Portfolio
date: 2021-01-25T01:11:48+00:00
author: mad.fed.eas
layout: page
guid: http://localhost/wordpress/?page_id=17
---
<h2 class="alignwide has-text-align-wide has-gigantic-font-size" style="line-height:1.1">
  A Few Portfolio Pieces
</h2>

<div style="height:1px" aria-hidden="true" class="wp-block-spacer">
</div>

<div class="wp-block-columns are-vertically-aligned-bottom">
  <div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:100%">
    <div class="wp-block-group">
      <div class="wp-block-group__inner-container">
        <div class="wp-block-columns has-yellow-color has-text-color">
          <div class="wp-block-column" style="flex-basis:100%">
            <p class="has-light-gray-color has-text-color">
              <span style="color:#5aecca" class="has-inline-color">My portfolio is constantly and evolving and growing. </span><span style="color:#ed24f9" class="has-inline-color">I&#8217;m always editing and tweaking my projects, eager to put my best foot forward.</span><span style="color:#5aecca" class="has-inline-color"> Click below to visit the sites, and</span> <span style="color:#f0622d" class="has-inline-color"><a href="http://localhost/wordpress/blog/" data-type="page" data-id="20">check out additional projects</a></span> <span style="color:#5aecca" class="has-inline-color">to see more!</span>
            </p>
            
            <div class="wp-block-group alignwide">
              <div class="wp-block-group__inner-container">
                <div class="wp-block-columns alignfull is-style-twentytwentyone-columns-overlap">
                  <div class="wp-block-column">
                    <figure class="wp-block-image alignfull size-large is-style-default"><img loading="lazy" width="1024" height="742" src="http://localhost/wordpress/wp-content/uploads/2021/02/jazzpiano-1-1024x742.jpg" alt="Jazz Piano Chord Analyzer" class="wp-image-46" srcset="http://localhost/wordpress/wp-content/uploads/2021/02/jazzpiano-1-1024x742.jpg 1024w, http://localhost/wordpress/wp-content/uploads/2021/02/jazzpiano-1-300x217.jpg 300w, http://localhost/wordpress/wp-content/uploads/2021/02/jazzpiano-1-768x556.jpg 768w, http://localhost/wordpress/wp-content/uploads/2021/02/jazzpiano-1.jpg 1226w" sizes="(max-width: 1024px) 100vw, 1024px" /><figcaption><span style="color:#14dc9d" class="has-inline-color">Jazz Piano Chord Analyzer &#8211; Showcases HTML, CSS, JavaScript</span></figcaption></figure> 
                    
                    <div style="height:1px" aria-hidden="true" class="wp-block-spacer">
                    </div><figure class="wp-block-image alignfull size-large is-style-twentytwentyone-image-frame">
                    
                    <img loading="lazy" width="1024" height="675" src="http://localhost/wordpress/wp-content/uploads/2021/02/jaysonnymenu-1024x675.jpg" alt="Jay and Sonny's Menu" class="wp-image-48" srcset="http://localhost/wordpress/wp-content/uploads/2021/02/jaysonnymenu-1024x675.jpg 1024w, http://localhost/wordpress/wp-content/uploads/2021/02/jaysonnymenu-300x198.jpg 300w, http://localhost/wordpress/wp-content/uploads/2021/02/jaysonnymenu-768x506.jpg 768w, http://localhost/wordpress/wp-content/uploads/2021/02/jaysonnymenu.jpg 1361w" sizes="(max-width: 1024px) 100vw, 1024px" /><figcaption><span style="color:#f9d224" class="has-inline-color">Jay and Sonny&#8217;s Pizza Parlor &#8211; Showcases JavaScript, JSON APIs</span></figcaption></figure>
                  </div>
                  
                  <div class="wp-block-column is-vertically-aligned-center">
                    <div style="height:1px" aria-hidden="true" class="wp-block-spacer">
                    </div><figure class="wp-block-image size-large is-style-default">
                    
                    <img loading="lazy" width="1024" height="742" src="http://localhost/wordpress/wp-content/uploads/2021/02/restaurantform-2-1024x742.jpg" alt="" class="wp-image-78" srcset="http://localhost/wordpress/wp-content/uploads/2021/02/restaurantform-2-1024x742.jpg 1024w, http://localhost/wordpress/wp-content/uploads/2021/02/restaurantform-2-300x217.jpg 300w, http://localhost/wordpress/wp-content/uploads/2021/02/restaurantform-2-768x557.jpg 768w, http://localhost/wordpress/wp-content/uploads/2021/02/restaurantform-2.jpg 1202w" sizes="(max-width: 1024px) 100vw, 1024px" /><figcaption><span style="color:#ed24f9" class="has-inline-color">Restaurant Contact Page &#8211; Showcases HTML, CSS</span></figcaption></figure>
                  </div>
                </div>
              </div>
            </div>
            
            <pre class="wp-block-verse"><span class="has-inline-color has-medium-gray-color">&lt;</span><span style="color:#3a6dd4" class="has-inline-color">p</span><span class="has-inline-color has-medium-gray-color"> </span><span style="color:#5aecca" class="has-inline-color">class=</span><span style="color:#f0622d" class="has-inline-color">"portfolio"</span><span class="has-inline-color has-medium-gray-color"> </span><span style="color:#5aecca" class="has-inline-color">id=</span><span style="color:#f0622d" class="has-inline-color">"code"</span><span class="has-inline-color has-medium-gray-color">>
</span><span class="has-inline-color has-white-color">Be sure to check out the</span><span class="has-inline-color has-medium-gray-color"> &lt;</span><span style="color:#3a6dd4" class="has-inline-color">a</span><span class="has-inline-color has-medium-gray-color"> </span><span style="color:#5aecca" class="has-inline-color">href=</span><span style="color:#f0622d" class="has-inline-color">"#"</span><span class="has-inline-color has-medium-gray-color">></span><span class="has-inline-color has-white-color">code</span><span class="has-inline-color has-medium-gray-color">&lt;/</span><span style="color:#3a6dd4" class="has-inline-color">a</span><span class="has-inline-color has-medium-gray-color">>
&lt;/</span><span style="color:#3a6dd4" class="has-inline-color">p</span><span class="has-inline-color has-medium-gray-color">></span></pre>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<pre class="wp-block-verse"><span style="color:#3a6dd4" class="has-inline-color">{</span><span style="color:#5aecca" class="has-inline-color">isInterested</span> <span class="has-inline-color has-medium-gray-color">?</span> <span style="color:#fbe069" class="has-inline-color">contactMadison</span><span class="has-inline-color has-medium-gray-color">()</span> : <span style="color:#fbe069" class="has-inline-color">keepReading</span><span class="has-inline-color has-medium-gray-color">()</span>;<span style="color:#3a6dd4" class="has-inline-color">}</span></pre>