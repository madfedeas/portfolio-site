---
id: 142
title: 'Coming Soon: My-React-App'
date: 2021-02-08T03:31:09+00:00
author: mad.fed.eas
layout: revision
guid: http://localhost/wordpress/2021/02/08/141-revision-v1/
permalink: /2021/02/08/141-revision-v1/
---
<pre class="wp-block-preformatted">import React, {Component} from 'react';
import Header from './Header';
import Content from './Content';
import Footer from './Footer';
class App extends Component {</pre>

<pre class="wp-block-preformatted">class App extends Component {
    render(){
       return(
        );
    }
}</pre>

More coming soon!