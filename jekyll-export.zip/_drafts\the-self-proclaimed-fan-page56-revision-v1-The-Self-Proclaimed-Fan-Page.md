---
id: 58
title: The Self-Proclaimed Fan Page
date: 2021-02-04T04:36:23+00:00
author: mad.fed.eas
layout: revision
guid: http://localhost/wordpress/2021/02/04/56-revision-v1/
permalink: /2021/02/04/56-revision-v1/
---
Originally, this project was a one-off assignment from my introduction to HTML and CSS course, but it has grown so much since then. The images and posts are so simple and easy to edit, so in order to spruce this project up, I decided to add some JavaScript into the mix. The code accesses JSON Placeholder, a free site with fake API for the user to add to their site. Then I took it one step further &#8211; I converted my CSS stylesheet into Less. Amazing how much one simple project can evolve!<figure class="wp-block-image size-large is-resized is-style-rounded">

<img loading="lazy" src="http://localhost/wordpress/wp-content/uploads/2021/02/fanpage-1024x814.jpg" alt="Fan Page - HTML, Less, JavaScript APIs" class="wp-image-57" width="920" height="731" srcset="http://localhost/wordpress/wp-content/uploads/2021/02/fanpage-1024x814.jpg 1024w, http://localhost/wordpress/wp-content/uploads/2021/02/fanpage-300x238.jpg 300w, http://localhost/wordpress/wp-content/uploads/2021/02/fanpage-768x610.jpg 768w, http://localhost/wordpress/wp-content/uploads/2021/02/fanpage.jpg 1097w" sizes="(max-width: 920px) 100vw, 920px" /> </figure>