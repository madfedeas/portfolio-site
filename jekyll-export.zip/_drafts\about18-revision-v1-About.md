---
id: 128
title: About
date: 2021-02-04T21:38:29+00:00
author: mad.fed.eas
layout: revision
guid: http://localhost/wordpress/2021/02/04/18-revision-v1/
permalink: /2021/02/04/18-revision-v1/
---
Hello, and welcome to my site! I am a former student of Cognitive Science and Biology, and a current student of Front End Web Development located in San Diego, California. My goal is to secure an entry-level position in front end development to improve my programming skills and find a team I can grow and learn with. I&#8217;m a dedicated and hard worker, a skilled multi-tasker, an enthusiastic and fast learner, and I&#8217;m excited to prove myself in a new job environment.