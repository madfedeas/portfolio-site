---
id: 28
title: Blog
date: 2021-01-25T01:11:48+00:00
author: mad.fed.eas
layout: revision
guid: http://localhost/wordpress/2021/01/25/20-revision-v1/
permalink: /2021/01/25/20-revision-v1/
---
