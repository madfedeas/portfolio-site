---
id: 40
title: Welcome to the site
date: 2021-01-25T01:14:47+00:00
author: mad.fed.eas
layout: revision
guid: http://localhost/wordpress/2021/01/25/24-revision-v1/
permalink: /2021/01/25/24-revision-v1/
---
My name is Madison Federin-Easley, and this is my first attempt at creating a portfolio site.

How cool is this WordPress stuff? It&#8217;s way easier than crafting these websites from scratch!

And yes, I know. Black is a rather boring theme. But it&#8217;ll be nice not to have a headache for once while I&#8217;m working on all this.

Alright. I&#8217;ve bored you long enough. Check out my projects below to see what else I&#8217;ve done (before figuring out how to install this and never, ever wanting to go back to building my own website ever again.