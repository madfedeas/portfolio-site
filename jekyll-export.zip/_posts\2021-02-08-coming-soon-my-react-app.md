---
id: 141
title: 'Coming Soon: My-React-App'
date: 2021-02-08T03:31:09+00:00
author: mad.fed.eas
layout: post
guid: http://localhost/wordpress/?p=141
permalink: /2021/02/08/coming-soon-my-react-app/
categories:
  - Portfolio Pieces
---
 

<pre class="wp-block-preformatted">import React, {Component} from 'react';
import Header from './Header';
import Content from './Content';
import Footer from './Footer';
class App extends Component {</pre>

<pre class="wp-block-preformatted">class App extends Component {
    render(){
       return(
        );
    }
}</pre>

More coming soon!