---
id: 1
title: RoShamBo!
date: 2021-01-25T00:47:38+00:00
author: mad.fed.eas
layout: post
guid: http://localhost/wordpress/?p=1
permalink: /2021/01/25/hello-world/
categories:
  - Portfolio Pieces
---
The game of Rock, Paper, Scissors has often been used to fairly settle a dispute or make a decision. Therefore the players&#8217; choices to throw rock, paper, or scissors should be random.&nbsp; However, as anyone who has played Rock, Paper, Scissors with another person will know, that is not always the case. In fact, there are guides online of how to guess what your opponent will throw and win the game! So if you truly want your decision to be made at random, why not play against a computer? 

The following webpage will run a game of Rock, Paper, Scissors. The user gets to choose what symbol to throw (entering numbers that represent those symbols), and the code will randomly generate a responding throw. The program will also keep track of who wins each round, allowing the user to play as long as they want and still know the outcome of all the matches combined.

<div class="wp-block-image is-style-default">
  <figure class="aligncenter size-large"><img loading="lazy" width="883" height="883" src="http://localhost/wordpress/wp-content/uploads/2021/02/roshambo-1.jpg" alt="" class="wp-image-72" srcset="http://localhost/wordpress/wp-content/uploads/2021/02/roshambo-1.jpg 883w, http://localhost/wordpress/wp-content/uploads/2021/02/roshambo-1-300x300.jpg 300w, http://localhost/wordpress/wp-content/uploads/2021/02/roshambo-1-150x150.jpg 150w, http://localhost/wordpress/wp-content/uploads/2021/02/roshambo-1-768x768.jpg 768w, http://localhost/wordpress/wp-content/uploads/2021/02/roshambo-1-666x666.jpg 666w" sizes="(max-width: 883px) 100vw, 883px" /></figure>
</div>

<p class="has-text-align-center">
  <a href="http://localhost/wordpress/2021/01/25/hello-world/rps/" data-type="URL" data-id="http://localhost/wordpress/2021/01/25/hello-world/rps/">Click here</a> to play the game yourself!
</p>