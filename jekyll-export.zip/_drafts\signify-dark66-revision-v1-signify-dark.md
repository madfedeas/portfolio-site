---
id: 110
title: signify-dark
date: 2021-02-04T20:50:06+00:00
author: mad.fed.eas
layout: revision
guid: http://localhost/wordpress/2021/02/04/66-revision-v1/
permalink: /2021/02/04/66-revision-v1/
---
.site-branding {max-width: 800px}